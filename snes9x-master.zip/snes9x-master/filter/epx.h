/*****************************************************************************\
     Snes9x - Portable Super Nintendo Entertainment System (TM) emulator.
                This file is licensed under the Snes9x License.
   For further information, consult the LICENSE file in the root directory.
\*****************************************************************************/

#ifndef _epx_h_
#define _epx_h_

void EPX_16 (uint8 *, int, uint8 *, int, int, int);

#endif
